% Rectangles a gauche
x=a+(b-a)*(0:N-1)/N;
Irect=(b-a)/N*sum(f(x));
